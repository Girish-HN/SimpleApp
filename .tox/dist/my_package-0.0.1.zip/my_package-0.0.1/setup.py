from setuptools import setup, find_packages

setup(
	name = 'my_package',
	version = '0.0.1',
	description = "Testing the package setup",
	author = 'Girish HN',
	packages = find_packages(),
	license = 'MIT'
)